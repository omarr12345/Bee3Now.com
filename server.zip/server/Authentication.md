Authentication

- Check access server

AUthorization

- Determine who is that user
-

User > Login >EMail/Password > Server >Authenticate > Yes > Authorization > Check permission

api/users/1/delete

user > Omar > Role > Admin > Permission > delete user ? Yes : NO

SPA | MPA

Browser <HTTP Protocal> Server

www.ggole.com >Request > server > HTML/CSS/JS

URL
VERB
HEADERS
DATA (OPTIONAL)

httpMessage = {
url: 'localhost:3001',
verb : 'GET|POST|DELAETE',
headers (settings, config): {}
body:{} (data)
}

HTTP PROTCOL IS "STATELESS PROTOCOL

Broswer > message (http request) > server > http response (HTTP PROTOCL)

Cookie <> Session
